import matplotlib.pyplot as plt
import numpy as np

results = open("ResultsOfSimulations.txt", 'r')

x_array =[]
y_array = []
for line in results:
    line = line.strip()
    words = line.split(': ')
    word = words[0].split()
    x_array.append(float(word[1]))
    y_array.append(float(words[1]))


results.close()

plt.plot(x_array, y_array)
plt.show()
