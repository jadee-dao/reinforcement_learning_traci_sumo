import traci
import numpy as np

class global_consts:
    TrafficLightId = "65616300"
    # Declare all globals in capital
    SumoConfig = "data/map.sumocfg"
    SumoCmd = ["sumo", "-c", SumoConfig, "--tripinfo-output", "data/tripinfo.xml",  "--start", "--no-warnings", "--time-to-teleport", "-1"]
    SumoCmd_GUI = ["sumo-gui", "-c", SumoConfig, "--tripinfo-output", "data/tripinfo.xml",  "--no-warnings", "--time-to-teleport", "-1"]
    StateSize = 19
    ActionSize = 8
    PhaseToActionRatio = 2
    MaxNumVehicleSeed = 400
    MinNumVehicleSeed = 100
    TripInfoFile = "data/tripinfo.xml"
    GenMapCmd = "python ./utilities/generateMap.py"
    OutputDir = "output"
    BenchMarkOutFile = "bm.txt"
    MapFile = "data/map.rou.xml"

def get_vehicle_in_each_direction():
    # W0, W1
    WT = traci.lane.getLastStepVehicleNumber("-393625777_0") + traci.lane.getLastStepVehicleNumber("-393625777_1")
    # W2
    WL = traci.lane.getLastStepVehicleNumber("-393625777_2")
    # E0, E1
    ET = traci.lane.getLastStepVehicleNumber("393627613_0") + traci.lane.getLastStepVehicleNumber("393627613_1")
    # E2
    EL = traci.lane.getLastStepVehicleNumber("393627613_2")
    # N0, N1
    NT = traci.edge.getLastStepVehicleNumber("-393645137") + traci.lane.getLastStepVehicleNumber("-393645126_0")
    # N2
    NL = traci.lane.getLastStepVehicleNumber("-393645126_2") + traci.lane.getLastStepVehicleNumber("-393645126_1")
    # S0, S1
    ST = traci.edge.getLastStepVehicleNumber("393645138") + traci.lane.getLastStepVehicleNumber("393645129_0")
    # S2
    SL = traci.lane.getLastStepVehicleNumber("393645129_2") + traci.lane.getLastStepVehicleNumber("393645129_1")
    return WT, WL, ET, EL, NT, NL, ST, SL

def get_halted_in_each_direction():
    # W0, W1
    WT = traci.lane.getLastStepHaltingNumber("-393625777_0") + traci.lane.getLastStepHaltingNumber("-393625777_1")
    # W2
    WL = traci.lane.getLastStepHaltingNumber("-393625777_2")
    # E0, E1
    ET = traci.lane.getLastStepHaltingNumber("393627613_0") + traci.lane.getLastStepHaltingNumber("393627613_1")
    # E2
    EL = traci.lane.getLastStepHaltingNumber("393627613_2")
    # N0, N1
    NT = traci.edge.getLastStepHaltingNumber("-393645137") + traci.lane.getLastStepHaltingNumber("-393645126_0")
    # N2
    NL = traci.lane.getLastStepHaltingNumber("-393645126_2") + traci.lane.getLastStepHaltingNumber("-393645126_1")
    # S0, S1
    ST = traci.edge.getLastStepHaltingNumber("393645138") + traci.lane.getLastStepHaltingNumber("393645129_0")
    # S2
    SL = traci.lane.getLastStepHaltingNumber("393645129_2") + traci.lane.getLastStepHaltingNumber("393645129_1")

    return WT, WL, ET, EL, NT, NL, ST, SL

# The phase for which light is on, cars are moving, so do
# not count those
def num_cars_halted_other_directions(curr_phase):

    WT, WL, ET, EL, NT, NL, ST, SL = get_halted_in_each_direction()

    total = WT + WL + ET + EL + NT + NL + ST + SL
    if curr_phase %2 == 1:
        curr_phase = curr_phase - 1

    if curr_phase == 4: #a
        cars_behind = total - WT - ET
    if curr_phase == 6: #a
        cars_behind = total - NT - ST
    if curr_phase == 0: #a
        cars_behind = total - WL - EL
    if curr_phase == 2: #s
        cars_behind = total - NL - SL

    if curr_phase == 8:
        cars_behind = total - ET - EL
    if curr_phase == 10: #a
        cars_behind = total - ST - SL
    if curr_phase == 12: #a
        cars_behind = total - WT - WL
    if curr_phase == 14:
        cars_behind = total - NT - NL

    return cars_behind




def num_cars_behind_line(curr_phase):

    WT, WL, ET, EL, NT, NL, ST, SL = get_vehicle_in_each_direction()

    if curr_phase %2 == 1:
        curr_phase = curr_phase - 1

    if curr_phase == 4:
        cars_behind = WT + ET
    if curr_phase == 6:
        cars_behind = NT + ST
    if curr_phase == 0:
        cars_behind = WL + EL
    if curr_phase == 2:
        cars_behind = NL + SL
    if curr_phase == 8:
        cars_behind = ET + EL
    if curr_phase == 10:
        cars_behind = ST + SL
    if curr_phase == 12:
        cars_behind = WT + WL
    if curr_phase == 14:
        cars_behind = NT + NL

    return cars_behind



def num_cars_halted_line(curr_phase):
    WT, WL, ET, EL, NT, NL, ST, SL = get_halted_in_each_direction()

    if curr_phase % global_consts.PhaseToActionRatio == 1:
        curr_phase = curr_phase - 1

    if curr_phase == 4:
        cars_behind = WT + ET
    if curr_phase == 6:
        cars_behind = NT + ST
    if curr_phase == 0:
        cars_behind = WL + EL
    if curr_phase == 2:
        cars_behind = NL + SL
    if curr_phase == 8:
        cars_behind = ET + EL
    if curr_phase == 10:
        cars_behind = ST + SL
    if curr_phase == 12:
        cars_behind = WT + WL
    if curr_phase == 14:
        cars_behind = NT + NL

    return cars_behind

def get_phase(action):
    return action * global_consts.PhaseToActionRatio

def increment_action(action, by_count):
    new_action = (action + by_count) % global_consts.ActionSize
    return new_action

def go_to_phase_that_has_halted_cars(action):

    max_iteration = 0
    while (num_cars_halted_line(get_phase(action)) == 0 and max_iteration < global_consts.ActionSize):

         action = increment_action(action, 1)
         #print("Loop:{} Action:{} \n".format(num_cars_halted_line(get_phase(action)), action))
         max_iteration += 1
    return action

def get_state(detectorIDs, phase_time, passed):
    state = []
    # halted in each direction (12 vals)
    for detector in detectorIDs:
        lane = traci.inductionloop.getLaneID(detector)
        halt = traci.lane.getLastStepHaltingNumber(lane)
        state.append(halt)

    halt = traci.lane.getLastStepHaltingNumber("393645138_0")
    state.append(halt)

    halt = traci.lane.getLastStepHaltingNumber("393645138_1")
    state.append(halt)

    halt = traci.lane.getLastStepHaltingNumber("-393645137_0")
    state.append(halt)

    halt = traci.lane.getLastStepHaltingNumber("-393645137_1")
    state.append(halt)

    # current phase (1 val)
    curr_phase = traci.trafficlights.getPhase(global_consts.TrafficLightId)
    state.append(curr_phase)

    # elapsedTime (1 val)
    #print("Elapsed:", phase_time)
    state.append(phase_time)

    # rateGoing (1 val)
    cars_passed = passed
    rate = cars_passed / phase_time
    state.append(rate)

    state = np.array(state)
    state = state.reshape((1, state.shape[0]))

    return state

def get_total_halt():
    total_halt = 0
    for edge in traci.edge.getIDList():
        total_halt += traci.edge.getLastStepHaltingNumber(edge)
    return total_halt

def fail_safe(new_action, action, phase_time):

    #curr_phase = traci.trafficlights.getPhase(global_consts.TrafficLightId)
    curr_phase = get_phase(action)
    new_halt = num_cars_halted_other_directions(curr_phase)
    if(new_halt == 0):
        # There is no car in other directions, keep current phase
        #print("Debug1: New halted: {} phase_time: {} current phase:{} Action:{} New Action:{} \n".format(new_halt, phase_time, curr_phase, action, new_action))
        return action
    cars_behindline_curr_phase = num_cars_behind_line(curr_phase)
    if(cars_behindline_curr_phase == 0 and (num_cars_behind_line(new_action * 2) == 0)):
        final_action = go_to_phase_that_has_halted_cars(action)
        #print("Debug2: Cuur phase cars behind: {} New halted: {} phase_time: {} current phase:{} Action:{} New Action:{} Final Action:{} \n".format(cars_behindline_curr_phase, new_halt, phase_time, curr_phase, action, new_action, final_action))
        return final_action

    #print("Debug3: New halted: {} phase_time: {} current phase:{} Action:{} New Action:{} \n".format(new_halt, phase_time, curr_phase, action, new_action))
    return new_action
