import numpy as np
import os, sys, time, traci
import shutil
from models.dqn import Dqn
from models.fixed import Fixed

from utilities.led import led_demo
from utilities.util import get_state
from utilities.util import global_consts
from utilities.util import num_cars_halted_other_directions
from utilities.util import fail_safe

import xml.etree.ElementTree as ET
import random, argparse


# Process and store options
class Options:
    def __init__(self):
        self.cmdParser = argparse.ArgumentParser(description="Artificially Intelligent Traffic Controller Version 1.0")
        self.args = ""
        self.model = "dqn"
        self.run = 3500
        self.runstep = 7
        self.weights = ""
        self.train = 20000
        self.demo = ""
        self.mapfile = ""
        self.switch_factor = 16
        self.log = ""
        self.verbosity = 0
        self.check = 1

        self.debug=False
        self.log_handle = None
        self.mode = "demo"
        self.epochs = 0
        self.world_record = ()

    def parse(self):
        self.cmdParser.add_argument("-m", "--model", choices=["fixed", "dqn", "ddqn", "ddpg"], default="dqn", help="Specify neural network model types to use for AI Traffic Controller")
        self.cmdParser.add_argument("-r", "--run", type=int, default=3500, help="Specify number of traci time units for which to run simulation")
        self.cmdParser.add_argument("-s", "--runstep", type=int, default=7, help="Specify number of traci time units for which to step simulation by")
        self.cmdParser.add_argument("-w", "--weights", default="", help="Specify file continating trained AI Traffic Controller model weights")
        # if want to make --train and --demo mutually exclusive toggle next 3 lines with 5th and 6th
        group = self.cmdParser.add_mutually_exclusive_group()
        group.add_argument("-t", "--train", type=int, default=0, help="Specify number of epochs to train the AI Traffic Controller model")
        group.add_argument("-d", "--demo", choices=["none", "cmd", "gui", "led"], default="none", help="Specify kind(s) of demo to be run")
        #self.cmdParser.add_argument("-t", "--train", type=int, default=0, help="Specify number of epochs to train the AI Traffic Controller model")
        #self.cmdParser.add_argument("-d", "--demo", choices=["none", "gui", "led", "all"], default="none", help="Specify kind(s) of demo to be run")
        self.cmdParser.add_argument("-p", "--pattern", default="", help="Specify map.rou XML file for traffic pattern")
        self.cmdParser.add_argument("-f", "--fixed_switch_factor", type=int, default=16, help="Specify a factor of runstep by which fixed traffic light state should switch")
        self.cmdParser.add_argument("-l", "--log", default="", help="Specify log file name")
        self.cmdParser.add_argument("-v", "--verbosity", type=int, choices=[0, 1, 2], default=1, help="Set verbosity level")
        self.cmdParser.add_argument("-c", "--check", type=int, choices=[0, 1], default=1, help="Set fail safe check level: 0 = disable, 1 = enable")
        self.args = self.cmdParser.parse_args()

        self.model = self.args.model
        self.run = self.args.run
        self.runstep = self.args.runstep
        self.weights = self.args.weights
        self.train = self.args.train
        self.demo = self.args.demo
        self.mapfile = self.args.pattern
        self.switch_factor = self.args.fixed_switch_factor
        self.log = self.args.log
        self.verbosity = self.args.verbosity
        self.check = self.args.check

        self.world_record = np.full(int(self.run/self.runstep + 1), 0)

        if(self.train > 0):
            self.mode = "training"
            self.epochs = self.train
        else:
            self.epochs = 1
            self.mode = "demo"


        if(not self.log==""):
            self.debug = True
            self.log_handle = open(self.log, "w+")
            if(not self.log_handle):
                print("Could not create {}".format(self.log))
                sys.exit(1)
            else:
                self.log_handle.write("*******Log of sumo run*********\n***************************\n\n")

        if(self.verbosity > 1):
            print("AI Model:{}, Run: {}, Weights:{}, Train:{}, Demo:{}, Log:{}, Vebosity:{}".format(self.model, self.run, self.weights, self.train, self.demo, self.log, self.verbosity))


def getAvgTimeLost():
    tree = ET.parse(global_consts.TripInfoFile)
    root = tree.getroot()
    tot_lost, max_lost, num = 0,0,0
    for child in root.findall('tripinfo'):
        x = child.attrib
        num += 1
        y = float(x['timeLoss'])
        tot_lost += y
        if(max_lost < y):
           max_lost = y
    return tot_lost / num

def cars_passed(passed):
    detectorIDs = traci.inductionloop.getIDList()
    cars_passed = passed
    for detector in detectorIDs:
        data = traci.inductionloop.getVehicleData(detector)
        if len(data) > 0:
            if data[0][3] > 0:
                cars_passed += 1
    return cars_passed

    #def calc_reward(old_halt, new_halt, new_passed, reward_factor):
    # passed should be high, new_halt should be less
    # old_halt - new_halt should be positive

    # passed = new_passed * reward_factor
    # change = old_halt - new_halt
    # reward = 0
    # if(passed == 0 ):
    #     if(new_halt == 0):
    #         reward = 100
    #     else:
    #         reward = - new_halt
    # else:
    #     if(new_halt == 0):
    #         reward = 100 + 16 * passed
    #     elif(change > 0):
    #         reward = 4 * passed
    #     elif(change == 0):
    #         reward = passed
    #     else:
    #         reward = change
    #
    # return reward

def calc_reward(old_halt, new_halt, new_passed, reward_factor):
    passed = new_passed
    change = old_halt - new_halt
    reward = 0
    if(passed == 0 ):
        if(new_halt == 0):
            reward = 0
        else:
            reward = - new_halt
    else:
        if(new_halt == 0):
            reward = 8 * passed
        elif(change > 0):
            reward = 4 * passed
        elif(change == 0):
            reward = passed
        elif(old_halt < new_halt):
            reward = change
        else:
            reward = - new_halt
    return reward


def main():

    #parse commandline
    options = Options()
    options.parse()
    #create dir/file etc.
    if(not os.path.exists(global_consts.OutputDir)):
        os.mkdir(global_consts.OutputDir)
    exploration = 0
    agent = None
    if(options.mode == "training"):
        exploration = 1

    if(options.model == "dqn"):
        agent = Dqn(global_consts.StateSize, global_consts.ActionSize, exploration)
    elif(options.model == "ddqn"):
        print("Error: Model {} is not implemented yet".format(options.model))
        exit(1)
    elif(options.model == "ddpg"):
        print("Error: Model {} is not implemented yet".format(options.model))
        exit(1)
    elif(options.model == "fixed"):
        agent = Fixed(global_consts.StateSize, global_consts.ActionSize, options.switch_factor)
    else:
        print("Error: Model {} is not implemented yet".format(options.model))
        exit(1)

    if(not options.weights==""):
        print("Loading weights: {}".format(options.weights))
        agent.load(options.weights)

    cmd=global_consts.SumoCmd
    if (options.mode == "demo"):
        if(options.demo == "cmd"):
            cmd = global_consts.SumoCmd
        else:
            cmd = global_consts.SumoCmd_GUI

    phase_time = 1
    # Start with 100 cars waiting
    total_lost_time = 0.0

    old_exploration = 0
    for simulation in range(options.epochs):

        gen_map_sim_steps = 0
        if(options.mapfile == ""):
            #generate random traffic pattern
            # Uniform random range over [global_consts.MinNumVehicleSeed, global_consts.MaxNumVehicleSeed - global_consts.MinNumVehicleSeed))
            gen_map_sim_steps = int(global_consts.MinNumVehicleSeed + np.random.random_sample() * (global_consts.MaxNumVehicleSeed - global_consts.MinNumVehicleSeed))
            os.system(global_consts.GenMapCmd + " " + repr(gen_map_sim_steps))
        else:
            shutil.copyfile(options.mapfile, global_consts.MapFile)

        if (options.mode == "demo"):
            if (options.demo == "led"):
                led_demo(options.runstep, options.run, agent)
                sys.exit(0)

        # Run last 4 epoch with predictor
        if (options.mode == "training"):
            if (simulation % 1000 == 0 ):
                old_exploration = agent.getMode()
                agent.setMode(0);

        #if( simulation % 100 == 0):
        #    cmd = global_consts.SumoCmd_GUI

        traci.start(cmd)
        # passed = cars_passed(0)
        passed = 0
        detectorIDs = traci.inductionloop.getIDList()
        state = get_state(detectorIDs, phase_time, passed)
        go = True
        predictor_count = 0
        total_halt = 0
        total_passed = 0
        total_reward = 0
        sim_step = 0
        phase_time = 0
        action = 0
        new_action = 0

        while sim_step < options.run and go:

            sim_batch = int(sim_step / options.runstep)
            new_action = agent.act(state, action)
            if(options.model == "fixed"):
                action = new_action
            else:
                if options.check == 1:
                    action = fail_safe(new_action, action, phase_time)
                else:
                    action = new_action

            if(agent.predicting() == True):
                predictor_count = predictor_count + 1

            curr_phase = traci.trafficlights.getPhase(global_consts.TrafficLightId)
            new_phase = action * 2
            phase_changed = False
            if(curr_phase != new_phase):
                phase_changed = True

            new_halt = num_cars_halted_other_directions(curr_phase)
            #for lane in traci.lane.getIDList():
            #    new_halt += traci.lane.getLastStepHaltingNumber(lane)
            old_halt = new_halt
            #print("Passed" + repr(passed) + " PhaseTime:" + repr(phase_time))
            if (passed/(phase_time + 1) < 0.1 and phase_time > 35) or (phase_time >= 7 and passed == 0) or phase_time > 50:
                new_phase = curr_phase + 2
                if new_phase == 16:
                    new_phase = 0

            if(phase_changed):
                passed = 0
                phase_time = 0

            old_passed = passed
            new_passed = 0
            for i in range(options.runstep):
                if(i==0 and phase_changed == True):
                    traci.trafficlights.setPhase(global_consts.TrafficLightId, curr_phase + 1)
                if(i ==2):
                    traci.trafficlights.setPhase(global_consts.TrafficLightId, new_phase)
                traci.simulationStep()
                sim_step += 1
                phase_time += 1
                passed = cars_passed(passed)

            new_passed = passed - old_passed
            #new_halt = 0
            #for lane in traci.lane.getIDList():
            #   new_halt += traci.lane.getLastStepHaltingNumber(lane)
            new_halt = num_cars_halted_other_directions(curr_phase)
            next_state = get_state(detectorIDs, phase_time, passed)
            reward_factor = 1
            if(options.mapfile == ""):
                # Changing traffic pattern
                reward_factor = 1
            else:
                #Fixed traffic pattern
                # Use world record to award more for beating the record
                reward_factor = (new_passed + 1)/(options.world_record[sim_batch] + 1)
                if (new_passed > options.world_record[sim_batch]):
                   options.world_record[sim_batch] = new_passed


            reward = calc_reward(old_halt, new_halt, new_passed, reward_factor)


            total_passed += new_passed
            total_reward += reward

            # Debugging log
            if(options.log_handle):
                if(options.verbosity > 0):
                    options.log_handle.write("Epoch:{} Sim Step:{} Old Halt:{} New Halt:{} Reward:{}\n".format(simulation, sim_step, old_halt, new_halt, reward))
                    options.log_handle.write("Phase Time:{} Car Passed:{} Predictor:{} Action:{} \n".format(phase_time, new_passed, agent.predicting(), action))
                if(options.verbosity > 1):
                    options.log_handle.write("State:{} \nNext State:{}\nQ Table:{}\n".format(tuple(state), tuple(next_state), tuple(agent.getQTable())))
                    options.log_handle.write("World Records: {}\n".format(options.world_record))
            # End debugging log

            if(options.mode == "training"):
                agent.remember(state, action, reward, next_state)
            state = next_state
            cars_left = traci.simulation.getMinExpectedNumber()
            if reward < -3000 or cars_left == 0:
                go = False

        traci.close()
        lost_time = float(getAvgTimeLost())
        performance = lost_time * sim_step
        # randomize traffic pattern
        # Unif[100, 400]: 100 to 400 cars
        if(options.verbosity > 0):
            print("Epoch:%i Predictor:%i Map Seed:%i Passed:%i End Sim Step:%i Lost Time:%i Reward:%i Cars Left:%i Performance:%i" % (simulation, predictor_count, gen_map_sim_steps, total_passed, sim_step, lost_time, total_reward, cars_left, performance))
        if(options.debug):
            if(options.verbosity > 0):
                options.log_handle.write("Epoch:{} Predictor:{} Map Seed:{} Passed:{} End Sim Step:{} Lost Time:{} Reward:{} Cars Left:{} Performance:{}\n".format(simulation, predictor_count, gen_map_sim_steps, total_passed, sim_step, lost_time, total_reward, cars_left, performance))
                if(options.verbosity > 1):
                    options.log_handle.write("Training Memory Len:{} \n".format(len(agent.getTrainingMemory())))

        if(options.mode == "training"):
            agent.replay()


        if (simulation % 1000 == 0) & (simulation != 0):
            agent.save(global_consts.OutputDir + "./traffic" + repr(simulation) + ".h5")

        if (options.mode == "training"):
            if (simulation % 1000 == 0 ):
                agent.setMode(old_exploration);

    if(options.log_handle):
        options.log_handle.close()

if __name__ == '__main__':
    main()
