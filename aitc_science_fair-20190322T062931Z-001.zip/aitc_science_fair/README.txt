<Add description here on how to install the whol package so that anyone can get started with it easily>

data: Folder containing data files that configure simulation of traci sumo
aitc.py : Main Artificiallly Intelligent Traffic Controller program
models: Neural Network models used by aitc
output: Output files other than log file, thse are temp files
utils: Library of unitity scripts used by aitc
README: this file

